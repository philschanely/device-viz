        </div>
        <footer>
            <p>Copyright &copy; 2014 by Phil Schanely. All rights reserved. <br/>
                Created as a course project for ITGM-727 at SCAD for Fall Quarter, 2014.</p>
        </footer>

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="{base_url}assets/js/bootstrap.min.js"></script>
        <script src='{base_url}assets/js/scrollReveal.min.js'></script>
        <script>
            window.sr = new scrollReveal();
        </script>
    </body>
</html>
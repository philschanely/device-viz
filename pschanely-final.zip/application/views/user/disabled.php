<h2>Account Disabled</h2>
<p>Your account has been disabled by the site administrator. You are not permitted to log in at this time.</p>
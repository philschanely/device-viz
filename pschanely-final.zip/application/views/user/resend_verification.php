<h2>Resending Verification...</h2>
<p>We're working on setting up this feature. Hang in there.</p>
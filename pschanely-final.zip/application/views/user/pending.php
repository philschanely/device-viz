<h2>Account Pending</h2>
<p>You must verify your email address before your account will be fully active. Check the email address with which you registered for an email from us and follow the link provided there to verify your address.</p>
<a class="btn btn-warning" href="{base_url}user/resend_verification/{user.user_id}">Resend verification</a>
<h2>Confirm to clear data</h2>
<p>Are you sure you want to clear all the data in the data period {start_date} {end_date}?</p>
<ul class="list-inline">
    <li><a class="btn-confirm" href="{base_url}data/clear/{period.period_id}/1">Yes</a></li>
    <li><a class="btn-cancel"  href="{base_url}data/index/{period.period_id}">No</a></li>
</ul>
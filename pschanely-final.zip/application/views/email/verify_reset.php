<h2>Password Reset</h2>
<p>Hello! You (or someone who knows your email address) just request to reset your password
    with DeviceViz. <a href="{base_url}user/password/reset/{user.user_id}/{user.action_code}">Reset your password &raquo;</a></p>
<p>Sincerely,<br />
    DeviceViz Administration</p>
<h2>Account Verification</h2>
<p>Welcome! You (or someone who knows your email address) just created an account for you 
    with DeviceViz. <a href="{base_url}user/verify/{user.user_id}/{user.action_code}">Verify your account  &raquo;</a></p>
<p>Sincerely,<br />
    DeviceViz Administration</p>